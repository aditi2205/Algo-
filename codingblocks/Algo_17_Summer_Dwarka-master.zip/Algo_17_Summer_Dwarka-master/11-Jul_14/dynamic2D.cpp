//Deepak Aggarwal, Coding Blocks
//deepak@codingblocks.com

#include <iostream>
using namespace std;
int main(){
	int M, N;
	cin >> M >> N;

	int ** mat = new int*[M];

	for(int i = 0; i < M; ++i){
		mat[i] = new int[N];
	}
}	